package com.example.fast;

import java.util.List;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 */

public class ApkScanWin {

    private Map<String,String> markNameMap;
    private String ApkFilePath;

    public ApkScanWin(){
        //ApkScanWin.this.fileChooser();
    }

    public void init(){
        FileTransferHandler fileTransferHandler = new FileTransferHandler(this);

    }


    public void fileChooser(){
        //绝对路径
        String absolutePath = getApkFilePath();
        if(absolutePath.endsWith(".apk")){
            List<String> result = MyUtil.readZipFile(absolutePath);
            if((result.size() == 1) && (((String)result.get(0)).startsWith("ERROR:"))){
                //显示错误信息
                System.out.println("ERROR:");
            }else {
                boolean flag = true;
                for(String fileName : result){
                    if(this.markNameMap.containsKey(fileName)){
                        //返回 加固的方式
                        String ss = (String)this.markNameMap.get(fileName)+"加固";
                        flag = false;
                        System.out.println(ss);
                        break;
                    }
                }
                if(flag){
                    //未采用加固方式
                    System.out.println("未加固或未知的加固方式");
                }
            }
        }

    }


    public Map<String, String> getMarkNameMap() {
        return markNameMap;
    }

    public void setMarkNameMap(Map<String, String> markNameMap) {
        this.markNameMap = markNameMap;
    }

    public String getApkFilePath() {
        return ApkFilePath;
    }

    public void setApkFilePath(String apkFilePath) {
        ApkFilePath = apkFilePath;
    }


}

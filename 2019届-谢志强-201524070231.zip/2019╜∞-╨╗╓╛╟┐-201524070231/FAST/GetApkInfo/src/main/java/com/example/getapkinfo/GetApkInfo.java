package com.example.getapkinfo;


import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetApkInfo {

    private static final int VERSION_CODE = 1;
    private static final String VERSION_NAME = "1.3.7";

    private static final int RET_FILE_NOT_GOOD = -2;
    private static final int RET_GET_INFO_BAD = -3;


    private static Map AppName;
    private static List AppNameKey;


    public static void main(String[] params){

        if((params.length == 0)){
            //参数错误
            return;
        }

        if(params[0].toLowerCase().startsWith("--help")){
            //帮助
            return;
        }else if(params[0].toLowerCase().startsWith("--version")){
            System.out.println(GetApkInfo.class.toString() + " vector like " + VERSION_NAME + ".2.5.2.5");
            return;
        }else if(params[0].toLowerCase().endsWith(".apk")){
            openApkFile(params[0]);
            return;
        }else {
            //失败
            return;
        }

    }


    private static void openApkFile(final String FilePath)
    {
        ApkUtil apkUtil = new ApkUtil();
        ApkInfo apkInfo = apkUtil.parseApk(FilePath);


        System.out.println(apkInfo.getPackageName());
        System.out.println("|"+apkInfo.getAppName());
        System.out.println("|"+apkInfo.getLaunchableActivity());
        System.out.println("|"+apkInfo.getMinSdkVersion());
        System.out.println("|"+apkInfo.getSdkVersion());
        System.out.println("|"+apkInfo.getSize());
        System.out.println("|"+apkInfo.getTargetSdkVersion());
        System.out.println("|"+apkInfo.getVersionCode());
        System.out.println("|"+apkInfo.getUsesPermissions());



//        System.out.println(apkInfo.getAppName()
//                +"|" +apkInfo.getPackageName()
//                +"|" +apkInfo.getSize()
//                +"|" +apkInfo.getMinSdkVersion()
//                +"|" +apkInfo.getVersionName()
//                +"|" + apkInfo.getVersionCode()
//        );


        /**
         * 以下为权限代码
         */

        //图标
        String iconPath = apkInfo.getIcon();

        //遍历ICON 列表
        PermissionsUtil permissionsUtil = new PermissionsUtil();
        List<String> list1 = permissionsUtil.getList_PermissionsKey();
        List<String> list2 = permissionsUtil.getList_PermissionsName();
        List<String> list3 = permissionsUtil.getList_PermissionsNotes();
        Map<String, Object> map = new HashMap<>();

        List list = apkInfo.getUsesPermissions();

        for (Object key : list) {
            boolean isput = false;
            for (int i = 0; i < list1.size(); i++) {
                if (key.equals(list1.get(i))) {
                    PermissionsObj permissionsObj = new PermissionsObj((String) key, list2.get(i), list3.get(i));
                    map.put((String) key, permissionsObj);
                    isput = true;
                    break;
                }
                if (isput == false) {
                    PermissionsObj permissionsObj = new PermissionsObj((String) key, "未知权限", "");
                    map.put((String) key, permissionsObj);
                }
            }
        }
    }


}

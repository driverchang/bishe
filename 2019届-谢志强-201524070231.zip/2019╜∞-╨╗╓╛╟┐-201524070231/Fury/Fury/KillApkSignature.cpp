﻿// KillApkSignature.cpp: 实现文件
//

#include "stdafx.h"
#include "Fury.h"
#include "KillApkSignature.h"
#include "afxdialogex.h"


// KillApkSignature 对话框

IMPLEMENT_DYNAMIC(KillApkSignature, CDialogEx)

KillApkSignature::KillApkSignature(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_FURY_DIALOG, pParent)
{

}

KillApkSignature::~KillApkSignature()
{
}

void KillApkSignature::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(KillApkSignature, CDialogEx)
END_MESSAGE_MAP()


// KillApkSignature 消息处理程序

BOOL KillApkSignature::killApkSignature(CString APKPath)
{

	CString path = _T(".\\..\\tool\\ApkSignatureKiller\\");

	int n = APKPath.ReverseFind('\\');
	CString apkName = APKPath;
	while (n)
	{
		apkName = apkName.Mid(n + 1, apkName.GetLength() - n);  //取'\'右边字符串
		n = apkName.Find('\\');   //不包含'\'，函数值返回-1 
		if (n == -1)
		{
			n = 0;
		}
	}
	CString CopyApkPath = path + apkName;
	CString RenameApk = path + "src.apk";

	if (CopyFile(APKPath, CopyApkPath, FALSE) == 0) {
		MessageBoxA(NULL, "发生意外的错误", "提示", 0);
		return FALSE;
	}

	CFile::Rename(CopyApkPath, RenameApk);

	return TRUE;
}

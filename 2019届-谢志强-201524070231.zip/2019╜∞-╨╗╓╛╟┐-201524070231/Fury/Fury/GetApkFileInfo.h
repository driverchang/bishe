#pragma once
class GetApkFileInfo
{
public:
	GetApkFileInfo();
	~GetApkFileInfo();




public:
	void GetApkFileInfo::OpenFileAndGetInfo(CString ApkPath);
	TCHAR* GetApkFileInfo::StringToChar(CString& str);
	CString GetApkFileInfo::ExecuteCmd(CString str);
	CString GetApkFileInfo::GetApkInfoData(int flag);
	CString* GetApkFileInfo::GetApkPermissionData();
};


﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 Fury.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FURY_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR_MAIN                131
#define IDD_DIALOG_SIGN                 135
#define IDB_BITMAP1                     144
#define IDC_EDIT_FILE_PATH              1000
#define IDC_BUTTON_LOAD_FILE            1001
#define IDC_LIST_INFO_VIEW              1002
#define IDC_BUTTON_FAN_BIAN_YI          1003
#define IDC_BUTTON3                     1004
#define IDC_BUTTON_FILE_INFO            1005
#define IDC_BUTTON5                     1006
#define IDC_BUTTON_APK_METHOD           1006
#define IDC_BUTTON_OPEN_JADX            1007
#define IDC_BUTTON7                     1008
#define IDC_BUTTON_SEC_EVALUATE         1008
#define IDC_BUTTON_BACK_TO_COMPILE      1009
#define IDC_BUTTON9                     1010
#define IDC_BUTTON_GET_SIGN_INFO        1010
#define IDC_BUTTON_KILL_SIGN_VERIFY     1011
#define IDC_BUTTON_SIGNATURE            1012
#define IDC_BUTTON_JIAGU                1013
#define IDC_COMBO1                      1014
#define IDC_BUTTON_INSTALL_APK          1015
#define IDC_EDIT_SIGN_FILE_PATH         1016
#define IDC_BUTTON_CONFIG_SIGN          1017
#define IDC_EDIT_ALIAS                  1018
#define IDC_EDIT_SIGN_PASSWORD          1019
#define IDC_EDIT_ALIAS_PASSWORD         1020
#define IDC_BUTTON_SIGN_VERIFY          1021
#define IDC_BUTTON_SIGN_MAKE            1022
#define IDC_BUTTON_SELECT_SIGN_FILE     1023
#define ID_BUTTON32771                  32771
#define ID_BUTTON32772                  32772
#define ID_BUTTON32773                  32773
#define ID_BUTTON32774                  32774
#define ID_BUTTON32775                  32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

﻿#pragma once
#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>

// SignConfigDlg 对话框

class SignConfigDlg : public CDialogEx
{
	DECLARE_DYNAMIC(SignConfigDlg)

public:
	SignConfigDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~SignConfigDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_SIGN };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSelectSignFile();
	afx_msg void OnBnClickedButtonSignVerify();
	afx_msg void OnBnClickedButtonSignMake();
public:

	CEdit mEdit_SignFilePath;
	CFont m_editFont;
	CEdit mEdit_Alias;
	CEdit mEdit_Sign_PassWord;
	CEdit mEdit_Alias_PassWord;

	void SignConfigDlg::GetSignEditText();
	TCHAR* SignConfigDlg::StringToChar(CString& str);
	CString SignConfigDlg::stringToCString(std::string& str);
	std::string SignConfigDlg::CStringTostring(CString& str);
	BOOL SignConfigDlg::WirteToConfigINI(CString sa, CString spw, CString apw);
	
};

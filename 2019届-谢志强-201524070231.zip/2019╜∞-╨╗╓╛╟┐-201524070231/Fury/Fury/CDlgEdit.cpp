#include "stdafx.h"
#include "CDlgEdit.h"


CDlgEdit::CDlgEdit()
{
}


CDlgEdit::~CDlgEdit()
{
}

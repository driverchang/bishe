#pragma once
class StartMobSF
{
public:
	StartMobSF();
	~StartMobSF();


public:
	BOOL StartMobSF::startProcessMobSF();
	TCHAR* StartMobSF::StringToChar(CString& str);
};


#include "stdafx.h"
#include "Tool.h"


Tool::Tool()
{
}


Tool::~Tool()
{
}


BOOL Tool::FolderCopy(CString SourceFile, CString TargetFile)
{
	CFileFind m_fileFind;
	if (SourceFile.IsEmpty()) {
		MessageBoxA(NULL, "�����ļ�����", "��ʾ", 0);
		return FALSE;
	}


	if (!m_fileFind.FindFile(TargetFile)) {
		CreateDirectory(TargetFile, NULL);    //Ŀ���ļ��в����ھʹ���
	}
	
	CFileFind finder;
	CString path;
	path.Format(_T("%s/*.*"), SourceFile);

	BOOL bWorking = finder.FindFile(path);
	while (bWorking) {
		bWorking = finder.FindNextFile();
		if (finder.IsDirectory() && !finder.IsDots()) {
			//FileCopy(finder.GetFilePath(), TargetFile + "/" + finder.GetFileName());
		}
		else {
			CopyFile(SourceFile, TargetFile + "/" + finder.GetFileName(), FALSE);
		}
	}


	return TRUE;
}



BOOL Tool::FileCopy(CString SourceFile, CString TargetFile)
{
	if (SourceFile.IsEmpty()) {
		MessageBoxA(NULL, "�����ļ�����", "��ʾ", 0);
		return FALSE;
	}

	if (CopyFile(SourceFile, TargetFile, FALSE) == 0) {
		return FALSE;
	}

	return TRUE;

}



CString Tool::ExecuteCmd(CString str)
{
	SECURITY_ATTRIBUTES sa;
	HANDLE hRead, hWrite;

	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		//MessageBox("Error on CreatePipe()!");
		return NULL;
	}
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	si.wShowWindow = SW_HIDE;
	si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	TCHAR* cmdline = StringToChar(str);
	if (!CreateProcess(NULL, cmdline, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		//MessageBox("Error on CreateProcess()!");
		return NULL;
	}

	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(hWrite);

	char buffer[8192];
	memset(buffer, 0, 8192);
	CString output;
	DWORD byteRead;

	
	while (true)
	{
		if (ReadFile(hRead, buffer, 8191, &byteRead, NULL) == NULL)
		{
			break;
		}
		output += buffer;
	}
	/*
	if ((ReadFile(hRead, buffer, 8191, &byteRead, NULL) != NULL)) {
		output += buffer;
	*/
	return output;
}


TCHAR* Tool::StringToChar(CString& str)
{
	int len = str.GetLength();
	TCHAR* tr = str.GetBuffer(len);
	str.ReleaseBuffer();
	return tr;
}



CString Tool::ExecuteCmdMax(CString str)
{
	SECURITY_ATTRIBUTES sa;
	HANDLE hRead, hWrite;

	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		//MessageBox("Error on CreatePipe()!");
		return NULL;
	}
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	si.wShowWindow = SW_HIDE;
	si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	TCHAR* cmdline = StringToChar(str);
	if (!CreateProcess(NULL, cmdline, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		//MessageBox("Error on CreateProcess()!");
		return NULL;
	}

	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(hWrite);

	char buffer[8192];
	memset(buffer, 0, 32468);
	CString output;
	DWORD byteRead;


	while (true)
	{
		if (ReadFile(hRead, buffer, 32468, &byteRead, NULL) == NULL)
		{
			break;
		}
		output += buffer;
	}
	/*
	if ((ReadFile(hRead, buffer, 8191, &byteRead, NULL) != NULL)) {
		output += buffer;
	*/
	return output;
}

BOOL Tool::ExecuteCmdNotWait(CString str)
{
	SECURITY_ATTRIBUTES sa;
	HANDLE hRead, hWrite;

	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;   //����Ҫ�����ܵ�
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		//MessageBox("Error on CreatePipe()!");
		return FALSE;
	}
	
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	si.wShowWindow = SW_HIDE;
	si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	TCHAR* cmdline = StringToChar(str);
	if (!CreateProcess(NULL, cmdline, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		//MessageBox("Error on CreateProcess()!");
		return FALSE;
	}

	CloseHandle(hWrite);

	return TRUE;
	
}


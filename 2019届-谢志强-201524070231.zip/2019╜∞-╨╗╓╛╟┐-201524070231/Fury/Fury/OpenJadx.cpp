#include "stdafx.h"
#include "OpenJadx.h"


OpenJadx::OpenJadx()
{
}


OpenJadx::~OpenJadx()
{
}



void OpenJadx::ProcessOpenJadx()
{


	PROCESS_INFORMATION pi;
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);

	//CString strCmdLine = _T(" /C ");
	//strCmdLine += _T("F:\\MyGitCode\\Fury\\tool\\jadx\\bin\\jadx-gui.bat");

	if (CreateProcess(L"F:\\MyGitCode\\Fury\\tool\\jadx\\bin\\jadx-gui.bat",
		NULL,
		NULL,
		NULL,
		FALSE,
		CREATE_NO_WINDOW,
		NULL,
		NULL,
		&si, &pi)) {
		WaitForSingleObject(pi.hProcess, INFINITE);
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
}
#pragma once

#include<Windows.h>
#include "Tool.h"


using namespace std;


class BackToCompile
{
public:
	BackToCompile();
	~BackToCompile();


public:
	CString RunBackToCompile(const CString& BackToCompileApkPath, CString outApk);
private:
	CString CallApkTool(const CString& BackToCompileApkPath,CString outPath);
	
};


#pragma once
#include<Windows.h>

class FindProtectType
{
public:
	FindProtectType();
	~FindProtectType();


public:
	bool FindApkShellType(const CString& strApkName);
	DWORD WINAPI fast(LPVOID lpParameter);
	TCHAR* FindProtectType::StringToChar(CString& str);
	CString FindProtectType::ExecuteCmd(CString str);

};


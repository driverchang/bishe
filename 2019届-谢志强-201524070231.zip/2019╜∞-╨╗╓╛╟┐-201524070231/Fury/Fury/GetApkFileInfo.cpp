#include "stdafx.h"
#include "GetApkFileInfo.h"
#define MAXPERMISSIONNUM 200

GetApkFileInfo::GetApkFileInfo()
{
}


GetApkFileInfo::~GetApkFileInfo()
{
}

typedef struct APKFILEINFO {
	CString PackageName;
	CString AppName;
	CString launchlabelActivity;
	CString minSdkVersion;
	CString sdkVersion;
	CString size;
	CString targetSdkVersion;
	CString VersionCode;
	CString usesPermissions[MAXPERMISSIONNUM];
}ApkFileInfo;



void GetApkFileInfo::OpenFileAndGetInfo(CString ApkPath)
{
	CString CmdLine = _T("java -jar F:\\MyGitCode\\Fury\\tool\\GetApkInfo.jar ");
	//CString ss = _T("F:\\��ҵ���\\����\\ShellApk\\ichunqiu.apk");
	CmdLine += ApkPath;

	CString temp = ExecuteCmd(CmdLine);
	CString temp1 = _T("");

	CArray<CString, CString>strArray;  //CString���͵Ķ�̬����
	while (temp.Find(_T("|")) + 1) {    //�Ҳ����ո��ʱ�򷵻�һ��-1
		strArray.Add(temp.Left(temp.Find(_T("|"))));
		temp.Delete(0, temp.Left(temp.Find(_T("|"))).GetLength() + 1);
		
	}
	strArray.Add(temp);
	ApkFileInfo apkFileInfo;
	apkFileInfo.PackageName = strArray[0];
	apkFileInfo.AppName = strArray[1];
	apkFileInfo.launchlabelActivity = strArray[2];
	apkFileInfo.minSdkVersion = strArray[3];
	apkFileInfo.sdkVersion = strArray[4];
	apkFileInfo.size = strArray[5];
	apkFileInfo.targetSdkVersion = strArray[6];
	apkFileInfo.VersionCode = strArray[7];

	CString Permission = strArray[8];
	CArray<CString, CString>permissionArray;            //���Ȩ��
	while (Permission.Find(_T(",")) + 1) {
		permissionArray.Add(Permission.Left(Permission.Find(_T(","))));
		Permission.Delete(0, Permission.Left(Permission.Find(_T(","))).GetLength() + 1);

	}
	permissionArray.Add(Permission);

	for (int i = 0; i < permissionArray.GetSize(); i++) {
		apkFileInfo.usesPermissions[i] = permissionArray[i];
	}

	
}


CString GetApkFileInfo::GetApkInfoData(int flag)
{
	ApkFileInfo apkFileInfo;
	CString Buf;
	switch (flag)
	{
	case 0:
		Buf = apkFileInfo.PackageName;
		return apkFileInfo.PackageName;
		break;
	case 1:
		return apkFileInfo.AppName;
		break;
	case 2:
		return apkFileInfo.launchlabelActivity;
		break;
	case 3:
		return apkFileInfo.minSdkVersion;
		break;
	case 4:
		return apkFileInfo.sdkVersion;
		break;
	case 5:
		return apkFileInfo.size;
		break;
	case 6:
		return apkFileInfo.targetSdkVersion;
		break;
	case 7:
		return apkFileInfo.VersionCode;
		break;
	default:
		MessageBox(NULL, L"δ֪ԭ���µĴ����Ҳ���", L"����",0);
		break;
	}
}



CString* GetApkFileInfo::GetApkPermissionData()
{
	ApkFileInfo afi;
	int MAXPERMISSIONNUMBER = 80;
	CString *perData = new CString[MAXPERMISSIONNUMBER];
	int i = 0;
	while (!afi.usesPermissions[i].IsEmpty()) {
		perData[i] = afi.usesPermissions[i][1];
		i++;
	}

	return perData;
}



/**
ͨ������cmdִ��jar�ļ�֮�󽫽�����ڹܵ�����
**/
CString GetApkFileInfo::ExecuteCmd(CString str)
{
	SECURITY_ATTRIBUTES sa;
	HANDLE hRead, hWrite;

	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		return NULL;
	}
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	si.wShowWindow = SW_HIDE;
	si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	TCHAR* cmdline = StringToChar(str);
	if (!CreateProcess(NULL, cmdline, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		//MessageBox("Error on CreateProcess()!");
		return NULL;
	}

	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(hWrite);

	char buffer[8192];
	memset(buffer, 0, 8192);
	CString output;
	DWORD byteRead;


	while (true)
	{
		if (ReadFile(hRead, buffer, 8191, &byteRead, NULL) == NULL)
		{
			break;
		}
		output += buffer;
	}

	return output;
}


TCHAR* GetApkFileInfo::StringToChar(CString& str)
{
	int len = str.GetLength();
	TCHAR* tr = str.GetBuffer(len);
	str.ReleaseBuffer();
	return tr;
}



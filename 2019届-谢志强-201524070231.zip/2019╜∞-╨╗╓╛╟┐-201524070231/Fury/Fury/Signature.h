#pragma once
class Signature
{
public:
	Signature();
	~Signature();
};


#include "stdafx.h"
#include "CDragEdit.h"


CDragEdit::CDragEdit()
{
}


CDragEdit::~CDragEdit()
{
}


CDragEdit::CDragEdit()
{
}


CDragEdit::~CDragEdit()
{
}


int CDragEdit::WM_CREATE()
{
	// TODO: �ڴ˴�����ʵ�ִ���.
	DragAcceptFile(TRUE);
	return 0;
}

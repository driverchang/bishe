#pragma once
class CSelectFolderDlg
{
public:
	CSelectFolderDlg();
	~CSelectFolderDlg();

public:
	static CString Show();
	
};


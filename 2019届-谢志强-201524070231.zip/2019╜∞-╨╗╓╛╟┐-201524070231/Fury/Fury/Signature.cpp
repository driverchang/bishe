#include "stdafx.h"
#include "Signature.h"


Signature::Signature()
{
}


Signature::~Signature()
{
}

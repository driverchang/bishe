#include "stdafx.h"
#include "BackToCompile.h"


BackToCompile::BackToCompile()
{
}


BackToCompile::~BackToCompile()
{
}


CString BackToCompile::RunBackToCompile(const CString& BackToCompileApkPath,CString outApk)
{
	CString callResult = CallApkTool(BackToCompileApkPath,outApk);
	return callResult;
}

CString BackToCompile::CallApkTool(const CString& BackToCompileApkPath,CString outPath)
{
	WCHAR sSysDir[MAX_PATH] = { 0 };
	GetSystemDirectory(sSysDir, MAX_PATH);
	CString strFullPath = sSysDir;
	strFullPath += _T("\\cmd.exe");
	CString strCmdLine = _T("java -jar ");
	CString apktool = _T("F:\\C++\\Fury\\tool\\apktool.jar");    //��ʱд��apktool��·��
	strCmdLine += apktool;
	strCmdLine += _T(" b ");
	strCmdLine += BackToCompileApkPath;   //����CMD��������  java -jar ...apktool.jar d *.apk
	strCmdLine += _T(" -o ");
	strCmdLine += outPath;

	Tool tool;
	CString result = tool.ExecuteCmd(strCmdLine);
	//һЩ�ı�
	//��������

	/****
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	BOOL bRunApkToolBack = CreateProcess(strFullPath.GetBuffer(), strCmdLine.GetBuffer(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
	int x = GetLastError();

	strFullPath.ReleaseBuffer();
	strCmdLine.ReleaseBuffer();

	//�жϽ����Ƿ񴴽����гɹ�
	if (!bRunApkToolBack) {
		return false;
	}

	//�ȴ��������н���֮��رվ��
	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(pi.hProcess);

	return true;

	***/

	return result;
}
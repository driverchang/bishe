#include "stdafx.h"
#include "FindProtectType.h"

#define MAX_THREADS 10


FindProtectType::FindProtectType()
{
}


FindProtectType::~FindProtectType()
{
}


/***
typedef struct MyData
{
	CString apkPath;
}MYDATA;
//������ѯ�ӹ����͵��߳�
DWORD WINAPI fast(LPVOID lpParameter)
{
	MYDATA *pmd = (MYDATA *)lpParameter;
	//printf("%d\n", pmd->apkPath);
	CString apkFile = pmd->apkPath;
	return 0;
}
***/

bool FindProtectType::FindApkShellType(const CString& strApkPath) {

	if (strApkPath.IsEmpty()) {
		return false;
	}
	if (strApkPath.Right(4) != _T(".apk")){
		MessageBoxA(NULL, "��ѡ��APK�ļ�", "��ʾ", 0);
		return false;
	}


	//printf("���������ļ��ĵ�ַ��%s" , strApkPath);


	//CMD�������ִ�к���н���ķ���
	CString CmdLineFast = _T("java -jar F:\\MyGitCode\\Fury\\tool\\fast.jar ");
	//CString ss = _T("F:\\��ҵ���\\����\\ShellApk\\ichunqiu.apk");
	CmdLineFast += strApkPath;
	CString temp = ExecuteCmd(CmdLineFast);
	
	MessageBox(NULL, temp.GetBuffer(), L"�ӹ̷�ʽ", 0);

	return true;

}




/**
ͨ������cmdִ��jar�ļ�֮�󽫽�����ڹܵ�����
**/
CString FindProtectType::ExecuteCmd(CString str)
{
	SECURITY_ATTRIBUTES sa;
	HANDLE hRead, hWrite;

	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		//MessageBox("Error on CreatePipe()!");
		return NULL;
	}
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	si.wShowWindow = SW_HIDE;
	si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	TCHAR* cmdline = StringToChar(str);
	if (!CreateProcess(NULL, cmdline, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		//MessageBox("Error on CreateProcess()!");
		return NULL;
	}
	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(hWrite);

	char buffer[8192];
	memset(buffer, 0, 8192);
	CString output;
	DWORD byteRead;
	while (true)
	{
		if (ReadFile(hRead, buffer, 8191, &byteRead, NULL) == NULL)
		{
			break;
		}
		output += buffer;
		Sleep(100);
	}
	return output;
}



TCHAR* FindProtectType::StringToChar(CString& str)
{
	int len = str.GetLength();
	TCHAR* tr = str.GetBuffer(len);
	str.ReleaseBuffer();
	return tr;
}










/** //�̴߳���

	MYDATA mydt[MAX_THREADS];
	mydt->apkPath = strApkName;
	HANDLE FAST = CreateThread(NULL, 0,NULL, &mydt[0], 0, NULL);
	CloseHandle(FAST);
	**/



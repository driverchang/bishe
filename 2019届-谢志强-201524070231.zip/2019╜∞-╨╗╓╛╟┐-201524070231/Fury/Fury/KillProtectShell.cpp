#include "stdafx.h"
#include "KillProtectShell.h"


KillProtectShell::KillProtectShell()
{
}


KillProtectShell::~KillProtectShell()
{
}

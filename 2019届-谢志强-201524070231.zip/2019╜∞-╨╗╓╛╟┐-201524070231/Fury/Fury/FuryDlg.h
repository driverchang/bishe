﻿
// FuryDlg.h: 头文件
//

#pragma once

#include<Windows.h>
#include<iostream>
#include<fstream>
#include<time.h>
#include <sys/timeb.h>
#include <ctime>
#include <string>
#include <sstream>
#include <iomanip>

#include "Decompilation.h"
#include "Fury.h"
#include "afxdialogex.h"
#include "BackToCompile.h"
#include "Tool.h"
#include "FindProtectType.h"
#include "OpenJadx.h"
#include "GetApkFileInfo.h"
#include "SignConfigDlg.h"
#include "KillApkSignature.h"
#include "CNListBox.h"
#include "CSelectFolderDlg.h"
#include "StartMobSF.h"



#define LISTSSS ((CNListBox* )(GetDlgItem(IDC_LIST_INFO_VIEW)))



// CFuryDlg 对话框
class CFuryDlg : public CDialogEx
{
// 构造
public:
	CFuryDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FURY_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:

	afx_msg void OnBnClickedButtonLoadFile();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnBnClickedButtonFanBianYi();
	TCHAR* StringToChar(CString& str);
	afx_msg void OnBnClickedButtonBackToCompile();
	afx_msg void OnEnChangeEditFilePath();



private:
	CString Select_File_PATH;     //选择的文件路径
	CString Select_File_Name;     //选择的文件名
	CString Select_File_Full_Path;
public:
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnBnClickedButtonFindProtectType();
	afx_msg void OnBnClickedButtonOpenJadx();
	afx_msg void OnBnClickedButtonFileInfo();
	afx_msg void OnBnClickedButtonApkSignature();
	afx_msg void OnBnClickedSignConfig();
	afx_msg void OnBnClickedButtonKillSignVerify();
public:
	CEdit m_EditControl_FilePath;
	CListBox mListBoxInfoView;
	CFont mFontSet;
	CString CFuryDlg::GetEditText();
	CString CFuryDlg::stringToCString(std::string& str);
	std::string CFuryDlg::CStringTostring(CString& cstr);
	void CFuryDlg::ClearListBoxAndViewTheTips(CString Tips);
	void CFuryDlg::ListBoxAddString(CString str);
	void CFuryDlg::SetHScroll();
	void CFuryDlg::OpenSaveFileDialog(CString FilePath, CString FileName);
	BOOL CFuryDlg::isOkApkFile(CString FilePath);
	UINT64 CFuryDlg::getCurrentTime();
	
	afx_msg void OnBnClickedButtonSecEvaluate();
	afx_msg void OnBnClickedButtonApkMethod();
	afx_msg void OnBnClickedButtonInstallApk();
	afx_msg void OnBnClickedButtonGetSignInfo();
};

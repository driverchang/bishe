﻿
// FuryDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "FuryDlg.h"
#include "Config.h"

#define BUFSIZE MAX_PATH


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()

};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CFuryDlg 对话框



CFuryDlg::CFuryDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_FURY_DIALOG, pParent)
	
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFuryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_FILE_PATH, m_EditControl_FilePath);
	DDX_Control(pDX, IDC_LIST_INFO_VIEW, mListBoxInfoView);
}

BEGIN_MESSAGE_MAP(CFuryDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FILE, &CFuryDlg::OnBnClickedButtonLoadFile)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CFuryDlg::OnCbnSelchangeCombo1)
	ON_BN_CLICKED(IDC_BUTTON_FAN_BIAN_YI, &CFuryDlg::OnBnClickedButtonFanBianYi)
	ON_BN_CLICKED(IDC_BUTTON_BACK_TO_COMPILE, &CFuryDlg::OnBnClickedButtonBackToCompile)
	ON_EN_CHANGE(IDC_EDIT_FILE_PATH, &CFuryDlg::OnEnChangeEditFilePath)
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_BUTTON3, &CFuryDlg::OnBnClickedButtonFindProtectType)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_JADX, &CFuryDlg::OnBnClickedButtonOpenJadx)
	ON_BN_CLICKED(IDC_BUTTON_FILE_INFO, &CFuryDlg::OnBnClickedButtonFileInfo)
	ON_BN_CLICKED(IDC_BUTTON_SIGNATURE, &CFuryDlg::OnBnClickedButtonApkSignature)
	ON_BN_CLICKED(IDC_BUTTON_CONFIG_SIGN, &CFuryDlg::OnBnClickedSignConfig)
	ON_BN_CLICKED(IDC_BUTTON_KILL_SIGN_VERIFY, &CFuryDlg::OnBnClickedButtonKillSignVerify)
	ON_BN_CLICKED(IDC_BUTTON_SEC_EVALUATE, &CFuryDlg::OnBnClickedButtonSecEvaluate)
	ON_BN_CLICKED(IDC_BUTTON_APK_METHOD, &CFuryDlg::OnBnClickedButtonApkMethod)
	ON_BN_CLICKED(IDC_BUTTON_INSTALL_APK, &CFuryDlg::OnBnClickedButtonInstallApk)
	ON_BN_CLICKED(IDC_BUTTON_GET_SIGN_INFO, &CFuryDlg::OnBnClickedButtonGetSignInfo)
END_MESSAGE_MAP()


// CFuryDlg 消息处理程序

BOOL CFuryDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	ChangeWindowMessageFilter(WM_DROPFILES, MSGFLT_ADD);
	ChangeWindowMessageFilter(0x0049, MSGFLT_ADD);
	DragAcceptFiles(TRUE);
	mListBoxInfoView.SetHorizontalExtent(200);

	//设置Edit控件中的文字居中，但是他娘的竟然不起作用
	RECT rect;
	GetDlgItem(IDC_EDIT_FILE_PATH)->GetClientRect(&rect);
	::OffsetRect(&rect, 0, 15);
	::SendMessageA(((CComboBox*)GetDlgItem(IDC_EDIT_FILE_PATH))->m_hWnd, EM_SETRECT, 0, (LPARAM)&rect);

	mFontSet.CreatePointFont(120, _T("宋体"));
	m_EditControl_FilePath.SetFont(&mFontSet);

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CFuryDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CFuryDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{

		CPaintDC   dc(this);
		CRect   rect;
		GetClientRect(&rect);                                 //获取对话框长宽       
		CDC   dcBmp;                                           //定义并创建一个内存设备环境
		dcBmp.CreateCompatibleDC(&dc);                         //创建兼容性DC
		CBitmap   bmpBackground;
		bmpBackground.LoadBitmap(IDB_BITMAP1);                 //载入资源中的IDB_BITMAP1图片
		BITMAP   m_bitmap;                                     //图片变量                
		bmpBackground.GetBitmap(&m_bitmap);                    //将图片载入位图中
		CBitmap   *pbmpOld = dcBmp.SelectObject(&bmpBackground); //将位图选入临时内存设备环境  
		//调用函数显示图片 StretchBlt显示形状可变
		dc.StretchBlt(0, 0, rect.Width(), rect.Height(), &dcBmp, 0, 0,
			m_bitmap.bmWidth, m_bitmap.bmHeight, SRCCOPY);
		
		//CDialogEx::OnPaint();
		//注释掉防止重复调用重画函数


		/*******
		



		CRect rc;
		GetWindowRect(&rc);
		CImage mImage;
		if (mImage.Load(_T("num1.jpg")) == S_OK) {
			mImage.Draw(GetDC()->GetSafeHdc(), CRect(0, 0, rc.Width(), rc.Height()));
		}
			**/

	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CFuryDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CFuryDlg::OnBnClickedButtonLoadFile()
{
	// TODO: 在此添加控件通知处理程序代码
	//打开文件
	CFileDialog open_file(TRUE,
		NULL,
		NULL,
		OFN_OVERWRITEPROMPT,
		_T("APK文件(*.apk; *.dex; *.jar)|*.apk; *.dex; *.jar| All Files(*.*)|*.*||"),
		NULL);
	
	if (open_file.DoModal() == IDOK) {

		Select_File_Full_Path = open_file.GetPathName();   //得到所选文件的路径
		Select_File_PATH = open_file.GetFolderPath();
		Select_File_Name = open_file.GetFileName();
		/**
		//从路径中截取到文件名
		string filepath = CT2A(file_select.GetBuffer());    //记得使用GetBuffer之后要释放
		int pos = filepath.find_first_of('/');
		string filename(filepath.substr(pos + 1));
		Select_File_Name = filename.c_str();
		**/

		CString TempPath = _T("F:\\MyGitCode\\Fury\\tool\\temp");
		CFileFind c_findfile;
		if (!c_findfile.FindFile(TempPath)) {
			CreateDirectory(TempPath, NULL);
		}
		CopyFile(Select_File_Full_Path, TempPath + "\\" + Select_File_Name, FALSE);


		SetDlgItemText(IDC_EDIT_FILE_PATH, Select_File_Full_Path);     //将文件的路径显示在显示框中
	}else {
		MessageBoxA(NULL, "打开文件的路径错误", "注意", 0);
	}


}



void CFuryDlg::OnCbnSelchangeCombo1()
{
	// TODO: 在此添加控件通知处理程序代码



}


/**********************************
		反编译应用
***********************************/
void CFuryDlg::OnBnClickedButtonFanBianYi()
{
	// TODO: 在此添加控件通知处理程序代码
	CString strApkPath = Select_File_PATH;
	CString strApkName = Select_File_Name;

	



	if (strApkPath.IsEmpty()) {
		MessageBoxA(NULL, "请选择文件！", "提示", 0);
		return;
	}

	/**
	if (!isOkApkFile(strApkPath)) {
		MessageBoxA(NULL, "请选择APK文件！", "提示", 0);
		return;
	}
	**/

	ClearListBoxAndViewTheTips(_T("正在准备反编译应用..."));

	//时间分析
	CString usedTime;
	long t1 = GetTickCount();

	//UINT64 startTime = getCurrentTime();


	Decompilation de;
	CString result = de.Run(strApkPath, strApkName);
		//进行显示


	CArray<CString, CString>strArray;  //CString类型的动态数组
	while (result.Find(_T("\r")) + 1) {    //找不到空格的时候返回一个-1
		strArray.Add(result.Left(result.Find(_T("\r"))));
		result.Delete(0, result.Left(result.Find(_T("\r"))).GetLength() + 2);

	}
	strArray.Add(result);

	for (int i = 0; i < strArray.GetSize() - 1; i++) {
		mListBoxInfoView.AddString(strArray[i]);
		Sleep(50);
	}

	mListBoxInfoView.AddString(L"反编译完成");
	//时间分析
	//UINT64 EndTime = getCurrentTime();
	//UINT64 UsedTime = EndTime - startTime;
	//CString temp;
	//temp.Format(TEXT("%u"), UsedTime/1000);
	//mListBoxInfoView.AddString(_T("共计用时：")+temp+ _T(" s"));
	long t2 = GetTickCount();//结束时间
	usedTime.Format(_T("time:%dms"), t2 - t1);
	mListBoxInfoView.AddString(usedTime);


}


//CString格式转化为TCHAR的格式
TCHAR* CFuryDlg::StringToChar(CString& str) {
	int len = str.GetLength();
	TCHAR* tr = str.GetBuffer(len);
	str.ReleaseBuffer();
	return tr;
}


/**********************************
		回编译应用
***********************************/
void CFuryDlg::OnBnClickedButtonBackToCompile()
{
	// TODO: 在此添加控件通知处理程序代码
	ClearListBoxAndViewTheTips(_T("开始回编译APK文件"));
	CString CurrentFilePath;
	GetDlgItemText(IDC_EDIT_FILE_PATH, CurrentFilePath);
	//得到当前的目录后调用apktool开始回编译
	if (CurrentFilePath.IsEmpty()) {
		MessageBoxA(NULL, "请选择反编译后的文件夹", "提示",0);
		return;
	}


	//这里需要处理一下，传进去的目录需要向上一层
	int pos = CurrentFilePath.ReverseFind('\\');
	CString ReBuildApkPath = CurrentFilePath.Left(pos+1);
	CString ReBuildApkName = CurrentFilePath.Right(CurrentFilePath.GetLength() - pos - 1);
	ReBuildApkName = _T("ReB_") + ReBuildApkName;
	ReBuildApkName += _T(".apk");


	CFileDialog dlg(FALSE, NULL, ReBuildApkName);//FALSE表示为“另存为”对话框，否则为“打开”对话框
	dlg.m_ofn.lpstrInitialDir = ReBuildApkPath;    //设置打开的默认目录

	//时间分析
	CString usedTime;
	long t1 = GetTickCount();

	if (dlg.DoModal() == IDOK)
	{
		CString strFile = dlg.GetPathName();//获取完整路径

		CStdioFile file;
		if (file.Open(strFile, CStdioFile::modeCreate | CStdioFile::modeNoTruncate | CStdioFile::modeWrite))//创建/打开文件
		{

			file.Close();//关闭输出文件
		}


		BackToCompile btc;

		CString result = btc.RunBackToCompile(CurrentFilePath,strFile);

		//进行显示
		CArray<CString, CString>strArray;  //CString类型的动态数组
		while (result.Find(_T("\r")) + 1) {    //找不到空格的时候返回一个-1
			strArray.Add(result.Left(result.Find(_T("\r"))));
			result.Delete(0, result.Left(result.Find(_T("\r"))).GetLength() + 2);

		}
		strArray.Add(result);



		for (int i = 0; i < strArray.GetSize() - 1; i++) {
			mListBoxInfoView.AddString(strArray[i]);
			Sleep(50);
		}

		mListBoxInfoView.AddString(L"回编译完成");
		mListBoxInfoView.AddString(L"准备进行签名...");
		UpdateWindow();

		CString Signcmdline = _T("java -jar ");
		Signcmdline += _T(".\\..\\tool\\apksigner.jar ");
		Signcmdline += _T("-keystore ");
		Signcmdline += _T("F:\\MyGitCode\\Fury\\tool\\signFile\\vector.keystore ");
		Signcmdline += _T("-alias androiddebugkey -pswd android ");
		Signcmdline += strFile;

		Tool tool;
		CString SignResult = tool.ExecuteCmd(Signcmdline);
		//进行显示
		CArray<CString, CString>SignstrArray;  //CString类型的动态数组
		while (SignResult.Find(_T("\r")) + 1) {    //找不到空格的时候返回一个-1
			SignstrArray.Add(SignResult.Left(SignResult.Find(_T("\r"))));
			SignResult.Delete(0, SignResult.Left(SignResult.Find(_T("\r"))).GetLength() + 2);
		}
		SignstrArray.Add(SignResult);
		for (int i = 0; i < SignstrArray.GetSize() - 1; i++) {
			mListBoxInfoView.AddString(SignstrArray[i]);
			Sleep(50);
		}

		mListBoxInfoView.AddString(L"签名完成！！");

	}





	//OpenSaveFileDialog(ReBuildApkPath, ReBuildApkName);
	long t2 = GetTickCount();//结束时间
	usedTime.Format(_T("time:%dms"), t2 - t1);
	mListBoxInfoView.AddString(usedTime);
	

	
}



void CFuryDlg::OnEnChangeEditFilePath()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。
	// TODO:  在此添加控件通知处理程序代码
}



//支持文件到对话框的任意拖拽功能
void CFuryDlg::OnDropFiles(HDROP hDropInfo)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	int count = DragQueryFile(hDropInfo, 0xFFFFFFFF, NULL, 0);
	for (int i = 0; i < count; ++i) {
		wchar_t filepath[MAX_PATH] = { 0 };
		if (DragQueryFile(hDropInfo, i, filepath, MAX_PATH) > 0) {
			m_EditControl_FilePath.SetWindowTextW(filepath);
		}
	}

	CDialogEx::OnDropFiles(hDropInfo);
}


/**********************************
		查壳
***********************************/
void CFuryDlg::OnBnClickedButtonFindProtectType()
{
	// TODO: 在此添加控件通知处理程序代码
	CString ApkPath = Select_File_Full_Path;
	//MessageBoxA(NULL, "执行正确", "OK", 0);
	if (ApkPath.IsEmpty()) {
		MessageBoxA(NULL, "请选择APK文件！", "提示", 0);
		return;
	}
	if (!isOkApkFile(ApkPath)) {
		MessageBoxA(NULL, "请选择APK文件！", "提示", 0);
		return;
	}

	FindProtectType fpt;
	fpt.FindApkShellType(ApkPath);

}



/**********************************
		jadx打开
***********************************/
void CFuryDlg::OnBnClickedButtonOpenJadx()
{
	// TODO: 在此添加控件通知处理程序代码
	//MessageBoxA(NULL, "Hello", "World", 0);

	OpenJadx oj;
	oj.ProcessOpenJadx();

}



/**********************************
		文件信息
***********************************/
void CFuryDlg::OnBnClickedButtonFileInfo()
{
	// TODO: 在此添加控件通知处理程序

	if (GetEditText().IsEmpty()) {
		MessageBoxA(NULL, "请选择文件！", "提示", 0);
		return;
	}
	if (!isOkApkFile(GetEditText())) {
		MessageBoxA(NULL, "请选择APK文件！", "提示", 0);
		return;
	}

	ClearListBoxAndViewTheTips(_T("检查文件信息："));


	CString CmdLine = _T("java -jar F:\\MyGitCode\\Fury\\tool\\GetApkInfo.jar ");
	//CString ss = _T("F:\\毕业设计\\资料\\ShellApk\\ichunqiu.apk");
	CmdLine += Select_File_Full_Path;
	GetApkFileInfo getApkFileInfo;
	CString temp = getApkFileInfo.ExecuteCmd(CmdLine);

	CArray<CString, CString>strArray;  //CString类型的动态数组
	while (temp.Find(_T("|")) + 1) {    //找不到空格的时候返回一个-1
		strArray.Add(temp.Left(temp.Find(_T("|"))));
		temp.Delete(0, temp.Left(temp.Find(_T("|"))).GetLength() + 1);

	}
	strArray.Add(temp);
	CString Permission;

	
	for (int i = 0; i < strArray.GetSize(); i++) {

		switch (i)
		{
		case 0:
			mListBoxInfoView.AddString(_T("包名：")+ strArray[i]);
			break;
		case 1:
			mListBoxInfoView.AddString(_T("APP名称：")+strArray[i]);
			break;
		case 2:
			mListBoxInfoView.AddString(_T("首启动页：") + strArray[i]);
			break;
		case 3:
			mListBoxInfoView.AddString(_T("最小SDK版本：") + strArray[i]);
			break;
		case 4:
			mListBoxInfoView.AddString(_T("SDK版本：") + strArray[i]);
			break;
		case 5:
			mListBoxInfoView.AddString(_T("包大小：") + strArray[i]);
			break;
		case 6:
			mListBoxInfoView.AddString(_T("TargetSdkVersion：") + strArray[i]);
			break;
		case 7:
			mListBoxInfoView.AddString(_T("VersionCode：") + strArray[i]);
			break;
		case 8:
			Permission = strArray[i];
			break;
		default:
			MessageBoxA(NULL, "未知原因导致的错误我不管", "错误", 0);
			break;
		}
		Sleep(50);
		UpdateWindow();
	}
	

	//权限显示
	CArray<CString, CString>perArray;  //CString类型的动态数组
	while (Permission.Find(_T(",")) + 1) {    //找不到空格的时候返回一个-1
		perArray.Add(Permission.Left(Permission.Find(_T(","))));
		Permission.Delete(0, Permission.Left(Permission.Find(_T(","))).GetLength() + 1);

	}
	perArray.Add(Permission);
	for (int i = 0; i < perArray.GetSize() - 1; i++) {
		mListBoxInfoView.AddString(perArray[i]);
		Sleep(50);
	}
}



//点击打开签名配置页
void CFuryDlg::OnBnClickedSignConfig()
{
	// TODO: 在此添加控件通知处理程序代码
	SignConfigDlg signConfigDlg;
	signConfigDlg.DoModal();

}



/**********************************
		签名
***********************************/
void CFuryDlg::OnBnClickedButtonApkSignature()
{
	// TODO: 在此添加控件通知处理程序代码
	//清除所有已显示的内容

	



	CString BeSignApkPath = GetEditText();

	if (!PathFileExists(BeSignApkPath)) {
		MessageBoxA(NULL, "请选择正确的文件", "提示", 0);
		return;
	}
	if (!isOkApkFile(BeSignApkPath)) {
		MessageBoxA(NULL, "请选择APK文件！", "提示", 0);
		return;
	}

	ClearListBoxAndViewTheTips(_T("开始签名："));
	
	//添加提示
	mListBoxInfoView.AddString(L"正在准备进行重签名，请稍等...");
	UpdateWindow();
	Sleep(50);
	

	CString cmdline = _T("java -jar ");
	cmdline += _T(".\\..\\tool\\apksigner.jar ");
	cmdline += _T("-keystore ");
	cmdline += _T("F:\\MyGitCode\\Fury\\tool\\signFile\\vector.keystore ");
	cmdline += _T("-alias androiddebugkey -pswd android ");
	cmdline += BeSignApkPath;

	Tool tool;

	
	//添加提示

	mListBoxInfoView.AddString(L"开始签名->"+ BeSignApkPath);
	UpdateWindow();
	Sleep(50);
	CString result = tool.ExecuteCmd(cmdline);

	
	mListBoxInfoView.AddString(result);

	ListBoxAddString(_T("签名完成！！"));
	Sleep(50);


	

}


/**********************************
		去除签名校验
***********************************/
void CFuryDlg::OnBnClickedButtonKillSignVerify()
{
	// TODO: 在此添加控件通知处理程序代码
	//清除所有已显示的内容
	while (mListBoxInfoView.GetCount()) {
		mListBoxInfoView.DeleteString(0);
	}
	CString APKPath = GetEditText();

	if (APKPath.IsEmpty()) {
		MessageBoxA(NULL, "请选择APK文件", "提示", 0);
		return;
	}
	if (!isOkApkFile(APKPath)) {
		MessageBoxA(NULL, "请选择APK文件！", "提示", 0);
		return;
	}

	ClearListBoxAndViewTheTips(_T("开始准备去除签名校验..."));

	
	int pos = APKPath.ReverseFind('\\');
	CString CurrentPath = APKPath.Left(pos + 1);

	KillApkSignature kas;
	Tool tool;
	CString cmdline = _T("java -jar nkstool.jar");
	TCHAR CurrentDir[BUFSIZE];
	DWORD dwRet;
	CString path = _T(".\\..\\tool\\ApkSignatureKiller\\");
	

	if (kas.killApkSignature(APKPath)) {
		
		dwRet = GetCurrentDirectory(BUFSIZE,CurrentDir);
		if (dwRet == 0) {
			return;
		}
		else if (dwRet > BUFSIZE) {
			MessageBoxA(NULL, "路径太长", "错误", 0);
			return;
		}

		if (!SetCurrentDirectory(path)) {
			MessageBoxA(NULL, "设置路径错误", "错误", 0);
			return;
		}
		CString result = tool.ExecuteCmd(cmdline);

		CString srcApk =  _T("F:\\MyGitCode\\Fury\\tool\\ApkSignatureKiller\\out.apk");
		CString outApk = CurrentPath + _T("out.apk");
		//复制输出的文件到源目录下
		if (CopyFile(srcApk, outApk, FALSE) == 0) {
			MessageBoxA(NULL, "我也不知道为啥就错了", "提示", 0);
			CString Error;
			DWORD wrong = GetLastError();
			Error.Format(_T("%d"), wrong);
		}

		//删除去除签名校验文件夹中的apk文件
		//想想怎么把这儿的路径弄成活的，写死就是找死
		DeleteFile(srcApk);
		DeleteFile(_T("F:\\MyGitCode\\Fury\\tool\\ApkSignatureKiller\\src.apk"));


		//执行完毕，返回原工作目录
		
		if (!SetCurrentDirectory(CurrentDir)) {
			MessageBoxA(NULL, "返回原工作目录失败", "错误", 0);
		}

		//进行显示
		CArray<CString, CString>strArray;  //CString类型的动态数组
		while (result.Find(_T("\r")) + 1) {    //找不到空格的时候返回一个-1
			strArray.Add(result.Left(result.Find(_T("\r"))));
			result.Delete(0, result.Left(result.Find(_T("\r"))).GetLength() + 2);

		}
		strArray.Add(result);
		for (int i = 0; i < strArray.GetSize() - 1; i++) {
			mListBoxInfoView.AddString(strArray[i]);
			Sleep(50);
		}

	}




}


//清除显示内容，显示提示
void CFuryDlg::ClearListBoxAndViewTheTips(CString Tips)
{
	//清除所有已显示的内容
	while (mListBoxInfoView.GetCount()) {
		mListBoxInfoView.DeleteString(0);
	}
	mListBoxInfoView.AddString(Tips);
	SetHScroll();
	UpdateWindow();
}

//ListBox进行显示
void CFuryDlg::ListBoxAddString(CString str)
{
	mListBoxInfoView.AddString(str);
	SetHScroll();
	UpdateWindow();
	
}
	
//得到 Edit框中的内容
CString CFuryDlg::GetEditText()
{
	CEdit* FilePath;
	FilePath = (CEdit*)GetDlgItem(IDC_EDIT_FILE_PATH);
	CString EditText;
	FilePath->GetWindowTextW(EditText);
	return EditText;
}

CString CFuryDlg::stringToCString(std::string& str)
{
#ifdef UNICODE
	int len = MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, NULL, 0);
	wchar_t *wstr = new wchar_t[len];
	memset(wstr, 0, len * sizeof(wchar_t));
	MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, wstr, len);
	CStringW output = wstr;
	delete[] wstr;

	return output;
#else
	return CString(input.c_str());
#endif // !UNICODE
}

std::string CFuryDlg::CStringTostring(CString& cstr)
{
#ifdef UNICODE
	int len = WideCharToMultiByte(CP_ACP, 0, LPCWSTR(cstr), -1, NULL, 0, NULL, NULL);
	char *str = new char[len];
	memset(str, 0, len);
	WideCharToMultiByte(CP_ACP, 0, LPCWSTR(cstr), -1, str, len, NULL, NULL);
	std::string output(str);
	delete[] str;
	return output;
#else
	return std::string((LPCSTR)input);
#endif // !UNICODE
}

/*View界面操作*/
void CFuryDlg::SetHScroll()
{
	CDC* dc = GetDC();
	SIZE s;
	int index;
	CString str;
	long temp;
	for (index = 0; index < mListBoxInfoView.GetCount(); index++)
	{
		mListBoxInfoView.GetText(index, str);
		s = dc->GetTextExtent(str, str.GetLength() + 1);   // 获取字符串的像素大小
														   // 如果新的字符串宽度大于先前的水平滚动条宽度，则重新设置滚动条宽度
														   // IDC_LISTBOX为m_List的资源ID
		temp = (long)SendDlgItemMessage(IDC_LIST_INFO_VIEW, LB_GETHORIZONTALEXTENT, 0, 0); //temp得到滚动条的宽度
		if (s.cx > temp)
		{
			SendDlgItemMessage(IDC_LIST_INFO_VIEW, LB_SETHORIZONTALEXTENT, (WPARAM)s.cx, 0);
		}
	}
	ReleaseDC(dc);
}



//文件另存为对话框
void CFuryDlg::OpenSaveFileDialog(CString FilePath,CString FileName)
{

	CFileDialog dlg(FALSE,NULL,FileName);//FALSE表示为“另存为”对话框，否则为“打开”对话框
	dlg.m_ofn.lpstrInitialDir = FilePath;    //设置打开的默认目录


	if (dlg.DoModal() == IDOK)
	{
		CString strFile = dlg.GetPathName();//获取完整路径
		          
		CStdioFile file;
		if (file.Open(strFile, CStdioFile::modeCreate | CStdioFile::modeNoTruncate | CStdioFile::modeWrite))//创建/打开文件
		{
		
			file.Close();//关闭输出文件
		}
	}

}


BOOL CFuryDlg::isOkApkFile(CString FilePath)
{
	if (!(FilePath.Right(4) == ".apk")) {
		return FALSE;
	}
	return TRUE;
}

/**********************************
		应用安全评测
***********************************/
void CFuryDlg::OnBnClickedButtonSecEvaluate()
{
	// TODO: 在此添加控件通知处理程序代码
	/******
	Frida框架
	inspekage框架   ----xposed模块       ----->需不需要集成xposed?
	Drozer
	框架的选择孰强孰弱，何去何从呢？
	大爷的，就选MobSF了
	******/

	/**
	MobSF是真的坑！！！！！！！！！！！！！！！！！
	*/
	CString ApkPath = Select_File_Full_Path;

	ClearListBoxAndViewTheTips(_T("正在准备启动评测框架,请稍后。。。"));

	StartMobSF sm;
	if (sm.startProcessMobSF()) {
		LISTSSS->AddString(_T("进入启动阶段，正在打开上传界面"));
	}
	else {
		LISTSSS->AddString(_T("启动失败，请检查MobSF框架的配置"));
	}

	Sleep(5000);
	//启动浏览器

	const TCHAR szOperation[] = _T("open");
	const TCHAR szAddress[] = _T("http://localhost:8000");

	HINSTANCE hRslt = ShellExecute(NULL, szOperation,
		szAddress, NULL, NULL, SW_SHOWNORMAL);

	assert(hRslt > (HINSTANCE)HINSTANCE_ERROR);

	LISTSSS->AddString(_T("上传界面打开完成！请选择文件进行分析"));



}



UINT64 CFuryDlg::getCurrentTime()      //直接调用这个函数就行了，返回值最好是int64_t，long long应该也可以
{
	using namespace std;

	timeb now;
	ftime(&now);
	std::stringstream milliStream;
	// 由于毫秒数不一定是三位数，故设置宽度为3，前面补0
	milliStream << setw(3) << setfill('0') << right << now.millitm;

	stringstream secStream;
	secStream << now.time;
	string timeStr(secStream.str());
	timeStr.append(milliStream.str());

	UINT64 timeLong;
	stringstream transStream(timeStr);
	transStream >> timeLong;

	return timeLong;
}


/**********************************
		安装APK文件至设备
***********************************/
void CFuryDlg::OnBnClickedButtonInstallApk()
{
	// TODO: 在此添加控件通知处理程序代码
	CString ApkPath = Select_File_Full_Path;
	
	Tool tool;
	memset(&tool, 0, sizeof(Tool));
	ClearListBoxAndViewTheTips(_T("正在安装APK文件"));
	CString CmdLine = _T("adb install ");
	CmdLine += ApkPath;

	//开启安装进程
	if (tool.ExecuteCmdNotWait(CmdLine)) {
		LISTSSS->AddString(_T("APK正在安装，请稍等..."));
	}
	else
	{
		LISTSSS->AddString(_T("安装失败!"));
	}
	
}




/**********************************
		获取应用文件的签名信息
***********************************/
void CFuryDlg::OnBnClickedButtonGetSignInfo()
{
	// TODO: 在此添加控件通知处理程序代码
	CString ApkPath = Select_File_Full_Path;
	ClearListBoxAndViewTheTips(_T("文件的签名信息如下："));
	
	Tool tool;

	CString CmdLine = _T("keytool -list -printcert -jarfile ");
	CmdLine += ApkPath;
	UpdateWindow();
	CString result = tool.ExecuteCmd(CmdLine);

	
	//mListBoxInfoView.AddString(result);
	CArray<CString, CString>strArray;    //CString类型的动态数组
	while (result.Find(_T("\n")) + 1) {    //找不到空格的时候返回一个-1
		strArray.Add(result.Left(result.Find(_T("\n"))));
		result.Delete(0, result.Left(result.Find(_T("\n"))).GetLength() + 1);
	}
	strArray.Add(result);
	for (int i = 0; i < strArray.GetSize() - 1; i++) {
		LISTSSS->AddString(strArray[i]);
		Sleep(50);
	}


}





/**********************************
		函数调用流程分析
***********************************/
void CFuryDlg::OnBnClickedButtonApkMethod()
{
	// TODO: 在此添加控件通知处理程序代码
	CString ApkPath = GetEditText();
	ClearListBoxAndViewTheTips(_T("开始插入Log代码。。。"));


	CString CmdLine = _T("python .//..//tool//inject_log//inject_log.py -c ");
	CmdLine += ApkPath;

	Tool tool;
	CString resultCrateInjectLog = tool.ExecuteCmd(CmdLine);
	LISTSSS->AddString(resultCrateInjectLog);
	UpdateWindow();
	LISTSSS->AddString(_T("路径写入完毕"));
	UpdateWindow();


	//打开Dialog选择目录
	//在此打开一个文件夹选择框进行文件夹的选择之后进行插入的动作

	CString WhatINeedFolder = CSelectFolderDlg::Show();
	if (WhatINeedFolder.IsEmpty()) {
		MessageBoxA(NULL, "请选择需要插入Log的文件", "提示", 0);
	}

	CString CmdLineF = _T("python .//..//tool//inject_log//inject_log.py -r ");
	CmdLineF += WhatINeedFolder;
	CString Result = tool.ExecuteCmd(CmdLineF);


	CArray<CString, CString>strArray;  //CString类型的动态数组
	while (Result.Find(_T("\n")) + 1) {    //找不到空格的时候返回一个-1
		strArray.Add(Result.Left(Result.Find(_T("\n"))));
		Result.Delete(0, Result.Left(Result.Find(_T("\n"))).GetLength() + 1);
	}
	strArray.Add(Result);
	for (int i = 0; i < strArray.GetSize() - 1; i++) {
		LISTSSS->AddString(strArray[i]);
		Sleep(50);
	}
	LISTSSS->AddString(_T("Log代码插入完毕，请选择根目录进行重打包工作。。。"));


}




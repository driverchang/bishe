#pragma once
class OpenJadx
{
public:
	OpenJadx();
	~OpenJadx();

	void OpenJadx::ProcessOpenJadx();
};


#pragma once
class KillProtectShell
{
public:
	KillProtectShell();
	~KillProtectShell();
};


#pragma once
#ifndef _IHLISTBOX_H_
#define _IHLISTBOX_H_

class CNListBox : public CListBox
{

public:

	int AddString(LPCTSTR lpszItem);
	int InsertString(int nIndex, LPCTSTR lpszItem);

	void RefushHorizontalScrollBar(void);

};

#endif



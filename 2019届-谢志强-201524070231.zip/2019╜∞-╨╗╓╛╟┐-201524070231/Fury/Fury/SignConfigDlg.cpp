﻿// SignConfigDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "Fury.h"
#include "SignConfigDlg.h"
#include "afxdialogex.h"
#include "Config.h"
#include "Tool.h"


// SignConfigDlg 对话框

IMPLEMENT_DYNAMIC(SignConfigDlg, CDialogEx)

SignConfigDlg::SignConfigDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_SIGN, pParent)
{

}

SignConfigDlg::~SignConfigDlg()
{
}

void SignConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_SIGN_FILE_PATH, mEdit_SignFilePath);
	DDX_Control(pDX, IDC_EDIT_ALIAS, mEdit_Alias);
	DDX_Control(pDX, IDC_EDIT_SIGN_PASSWORD, mEdit_Sign_PassWord);
	DDX_Control(pDX, IDC_EDIT_ALIAS_PASSWORD, mEdit_Alias_PassWord);
}


BOOL SignConfigDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();


	m_editFont.CreatePointFont(120, _T("宋体"));
	mEdit_SignFilePath.SetFont(&m_editFont);


	/*
	让EditControl中的文字垂直居中的代码，但是没毛用

	CRect rect;
	mEdit_SignFilePath.GetClientRect(rect);
	TEXTMETRIC tm;
	mEdit_SignFilePath.GetDC()->GetTextMetrics(&tm);

	int nFontHeight = tm.tmHeight + tm.tmExternalLeading;
	int nOffY = (rect.Height() - nFontHeight) / 2;
	::OffsetRect(&rect, 0, nOffY);
	::SendMessage(mEdit_SignFilePath.m_hWnd, EM_SETRECT, 0, (LPARAM)&rect);
	*/
	

	return TRUE;
}



BEGIN_MESSAGE_MAP(SignConfigDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_SELECT_SIGN_FILE, &SignConfigDlg::OnBnClickedButtonSelectSignFile)
	ON_BN_CLICKED(IDC_BUTTON_SIGN_VERIFY, &SignConfigDlg::OnBnClickedButtonSignVerify)
	ON_BN_CLICKED(IDC_BUTTON_SIGN_MAKE, &SignConfigDlg::OnBnClickedButtonSignMake)
END_MESSAGE_MAP()


// SignConfigDlg 消息处理程序




void SignConfigDlg::OnBnClickedButtonSelectSignFile()
{
	// TODO: 在此添加控件通知处理程序代码
	CFileDialog open_file(TRUE,
		NULL,
		NULL,
		OFN_OVERWRITEPROMPT,
		_T("密钥文件(*.keystore)|*.keystore"),
		NULL);

	if (open_file.DoModal() == IDOK) {

		SetDlgItemText(IDC_EDIT_SIGN_FILE_PATH,open_file.GetPathName());     //将文件的路径显示在显示框中
	}
	else {
		MessageBoxA(NULL, "打开文件的路径错误", "注意", 0);
	}



}


void SignConfigDlg::OnBnClickedButtonSignVerify()
{
	// TODO: 在此添加控件通知处理程序代码
	CEdit* SignFilePath;
	CEdit* SignAlias;
	CEdit* SignPassWord;
	CEdit* AliasPassWord;

	SignFilePath = (CEdit*)GetDlgItem(IDC_EDIT_SIGN_FILE_PATH);
	SignAlias = (CEdit*)GetDlgItem(IDC_EDIT_ALIAS);
	SignPassWord = (CEdit*)GetDlgItem(IDC_EDIT_SIGN_PASSWORD);
	AliasPassWord = (CEdit*)GetDlgItem(IDC_EDIT_ALIAS_PASSWORD);
	CString sfp;  //Sign文件path
	SignFilePath->GetWindowTextW(sfp);
	CString sa; //输入的别名
	SignAlias->GetWindowTextW(sa);
	CString spw; //签名密码
	SignPassWord->GetWindowTextW(spw);
	CString apw; //别名密码
	AliasPassWord->GetWindowTextW(apw);

	//首先对于输入的 内容进行判空
	if (sfp == "" || sa == "" || spw == "" || apw == "")
	{
		MessageBoxA(NULL, "输入不能为空", "提示", 0);
		return;
	}

	CString cmdLine = _T("java -jar ");
	cmdLine += _T(".\\..\\tool\\keyver.jar ");
	cmdLine += sfp + _T(" ") + spw + _T(" ") + sa + _T(" ") + apw;
	
	Tool tool;
	CString result = tool.ExecuteCmd(cmdLine);
	
	MessageBox(result.GetBuffer(), L"校验提示", 0);
	result.ReleaseBuffer();

}


void SignConfigDlg::OnBnClickedButtonSignMake()
{
	// TODO: 在此添加控件通知处理程序代码

	CEdit* SignFilePath;
	CEdit* SignAlias;
	CEdit* SignPassWord;
	CEdit* AliasPassWord;

	SignFilePath = (CEdit*)GetDlgItem(IDC_EDIT_SIGN_FILE_PATH);
	SignAlias = (CEdit*)GetDlgItem(IDC_EDIT_ALIAS);
	SignPassWord = (CEdit*)GetDlgItem(IDC_EDIT_SIGN_PASSWORD);
	AliasPassWord = (CEdit*)GetDlgItem(IDC_EDIT_ALIAS_PASSWORD);
	CString sfp;  //Sign文件path
	SignFilePath->GetWindowTextW(sfp);
	CString sa; //输入的别名
	SignAlias->GetWindowTextW(sa);
	CString spw; //签名密码
	SignPassWord->GetWindowTextW(spw);
	CString apw; //别名密码
	AliasPassWord->GetWindowTextW(apw);

	//首先对于输入的 内容进行判空
	if (sfp == "" || sa == "" || spw == "" || apw == "")
	{
		MessageBoxA(NULL, "输入不能为空", "提示", 0);
		return;
	}

	//Sign文件的路径应当复制一份到tool目录下
	Tool tool;
	CString target = _T(".\\..\\tool\\signFile\\vector.keystore");
	tool.FileCopy(sfp, target);


	if (WirteToConfigINI(sa, spw, apw)) {
		MessageBoxA(NULL, "写入成功", "提示", 0);
	}
	
	

}


void SignConfigDlg::GetSignEditText()
{

}



//校验完毕之后写入配置文件
BOOL SignConfigDlg::WirteToConfigINI(CString sa,CString spw,CString apw)
{

	std::string strConfigFileName(".\\..\\tool\\config.ini");
	std::ofstream out(strConfigFileName);

	out << "#test for config read only and write\n";


	sa = _T("alias = ") + sa;
	sa += _T("\n");

	out << CStringTostring(sa);
	out.close();

	//初始化Config类
	Config config(strConfigFileName);

	//读取键值
	std::string strKey = "alias";
	std::string strValue;
	strValue = config.Read<std::string>(strKey);


	// 写入新键值对
	config.Add<std::string>("signPass", CStringTostring(spw));
	config.Add<std::string>("aliasPass", CStringTostring(apw));

	// 将 Config 类的修改写入文件
	out.open(strConfigFileName, std::ios::app);
	if (out.is_open()) {
		// 利用 Config 类的 << 重载运算符
		out << config;
		std::cout << "Write config content success!" << std::endl;
	}
	out.close();
		
	return TRUE;

}


TCHAR* SignConfigDlg::StringToChar(CString& str)
{
	int len = str.GetLength();
	TCHAR* tr = str.GetBuffer(len);
	str.ReleaseBuffer();
	return tr;
}


CString SignConfigDlg::stringToCString(std::string& str)
{
#ifdef UNICODE
	int len = MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, NULL, 0);
	wchar_t *wstr = new wchar_t[len];
	memset(wstr, 0, len * sizeof(wchar_t));
	MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, wstr, len);
	CStringW output = wstr;
	delete[] wstr;

	return output;
#else
	return CString(input.c_str());
#endif // !UNICODE
}

std::string SignConfigDlg::CStringTostring(CString& cstr)
{
#ifdef UNICODE
	int len = WideCharToMultiByte(CP_ACP, 0, LPCWSTR(cstr), -1, NULL, 0, NULL, NULL);
	char *str = new char[len];
	memset(str, 0, len);
	WideCharToMultiByte(CP_ACP, 0, LPCWSTR(cstr), -1, str, len, NULL, NULL);
	std::string output(str);
	delete[] str;
	return output;
#else
	return std::string((LPCSTR)input);
#endif // !UNICODE
}
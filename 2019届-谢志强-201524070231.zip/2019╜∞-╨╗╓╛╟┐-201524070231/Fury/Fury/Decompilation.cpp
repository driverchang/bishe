#include "stdafx.h"
#include "Decompilation.h"
#include "FuryDlg.h"



Decompilation::Decompilation()
{
	
}


Decompilation::~Decompilation()
{
}


CString Decompilation::Run(const CString& strApkDir, const CString& strApkName) {

	WCHAR sOldDir[MAX_PATH] = { 0 };
	GetCurrentDirectory(MAX_PATH, sOldDir);

	SetCurrentDirectory(strApkDir);
	CString bCalRest = CallApkTool(strApkName);

	SetCurrentDirectory(sOldDir);


	return bCalRest;
}

/**********************************
	����apktool��jar��
***********************************/
CString Decompilation::CallApkTool(const CString& strApkName) {

	if (strApkName.IsEmpty()) {
		return false;
	}
	
	WCHAR sSysDir[MAX_PATH] = { 0 };
	GetSystemDirectory(sSysDir, MAX_PATH);


	//��������Դ�ļ���CMD Command
	CString strCmdLine = _T("java -jar ");
	CString apktool = _T("F:\\MyGitCode\\Fury\\tool\\apktool.jar"); 
	strCmdLine += apktool;
	strCmdLine += _T(" d ");
	strCmdLine += strApkName;
	//����CMD��������  java -jar ...apktool.jar d *.apk

	//������Դ�ļ���command
	CString NoResCmdLine = _T("java -jar ");
	NoResCmdLine += apktool;
	NoResCmdLine += _T(" d -r ");
	NoResCmdLine += strApkName;

	Tool tool;
	CString result;
	if (MessageBoxA(NULL, "�Ƿ���Ҫ������Դ�ļ�", "��ʾ", MB_YESNO) == IDYES) {
		result = tool.ExecuteCmd(NoResCmdLine);
	}
	else {
		result = tool.ExecuteCmd(strCmdLine);
	}


	/***
	//��������
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	BOOL bRunApkTool = CreateProcess(strFullPath.GetBuffer(), strCmdLine.GetBuffer(), NULL,NULL,FALSE, 0, NULL, NULL, &si, &pi);
	int x = GetLastError();

	strFullPath.ReleaseBuffer();
	strCmdLine.ReleaseBuffer();

	//�жϽ����Ƿ񴴽����гɹ�
	if (!bRunApkTool) {
		return false;
	}

	//�ȴ��������н���֮��رվ��
	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(pi.hProcess);

	return true;

	*/

	return result;

}
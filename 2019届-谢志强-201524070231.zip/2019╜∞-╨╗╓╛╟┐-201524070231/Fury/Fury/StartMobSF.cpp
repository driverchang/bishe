#include "stdafx.h"
#include "StartMobSF.h"


StartMobSF::StartMobSF()
{
}


StartMobSF::~StartMobSF()
{
}


BOOL StartMobSF::startProcessMobSF() 
{

	SECURITY_ATTRIBUTES sa;
	HANDLE hRead, hWrite;

	//����bat������
	CString CmdStr = _T("E:\\MobSF\\NewMaster\\Mobile-Security-Framework-MobSF\\run.bat");


	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		//MessageBox("Error on CreatePipe()!");
		return FALSE;
	}
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	si.wShowWindow = SW_HIDE;
	si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	TCHAR* cmdline = StringToChar(CmdStr);
	if (!CreateProcess(NULL, cmdline, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		//MessageBox("Error on CreateProcess()!");
		return FALSE;
	}

	//WaitForSingleObject(pi.hProcess, INFINITE);        //�첽ִ�� ��ֹ����
	CloseHandle(hWrite);
	return TRUE;
}


TCHAR* StartMobSF::StringToChar(CString& str)
{
	int len = str.GetLength();
	TCHAR* tr = str.GetBuffer(len);
	str.ReleaseBuffer();
	return tr;
}

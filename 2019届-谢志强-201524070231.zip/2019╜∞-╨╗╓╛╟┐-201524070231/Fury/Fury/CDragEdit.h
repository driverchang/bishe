#pragma once
#include <afxwin.h>
#include <afxwin.h>
class CDragEdit :
	public CEdit
{
public:
	CDragEdit();
	~CDragEdit();
	int WM_CREATE();
};

class CDragEdit :
	public CEdit
{
public:
	CDragEdit();
	~CDragEdit();
};


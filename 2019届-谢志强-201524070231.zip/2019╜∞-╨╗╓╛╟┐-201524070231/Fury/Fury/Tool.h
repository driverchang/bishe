#pragma once

#include<Windows.h>
#include<fileapi.h>
#include<fstream>
#include<iostream>



class Tool
{
public:
	Tool();
	~Tool();
public:
	BOOL FolderCopy(CString SourceFile, CString TargeFile);
	CString Tool::ExecuteCmd(CString str);
	TCHAR* Tool::StringToChar(CString& str);
	BOOL Tool::FileCopy(CString SourceFile, CString TargetFile);
	CString Tool::ExecuteCmdMax(CString str);
	BOOL Tool::ExecuteCmdNotWait(CString str);
};

